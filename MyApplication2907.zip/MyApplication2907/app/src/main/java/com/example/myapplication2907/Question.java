package com.example.myapplication2907;

import java.util.List;

public class Question {

    public String q;
    public List<Answer> a;

}
