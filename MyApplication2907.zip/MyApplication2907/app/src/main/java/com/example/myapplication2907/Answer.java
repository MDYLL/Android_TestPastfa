package com.example.myapplication2907;

import java.util.List;

public class Answer {
    public String title;
    List<Integer> vector;

}
