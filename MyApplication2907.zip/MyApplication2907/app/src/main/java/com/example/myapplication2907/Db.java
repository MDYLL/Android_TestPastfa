package com.example.myapplication2907;

import java.util.List;

public class Db {
    public List<Question> questions;
}