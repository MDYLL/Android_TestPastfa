package com.example.myapplication2907;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyViewHolder> {

    private List<Answer> mAnswerList;

    MyRecyclerViewAdapter(List<Answer> catList) {
        this.mAnswerList = catList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapter.MyViewHolder holder, int position) {
        Answer answer=mAnswerList.get(position);
        holder.currentAnswer.setText(answer.title);

    }

    @Override
    public int getItemCount() {
        return 0;
    }
    static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView currentAnswer;

        MyViewHolder(View itemView) {
            super(itemView);
            currentAnswer = itemView.findViewById(R.id.answer);
        }
    }
}
